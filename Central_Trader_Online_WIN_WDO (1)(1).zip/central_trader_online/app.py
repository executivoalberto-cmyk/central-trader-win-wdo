from flask import Flask, jsonify, render_template
from datetime import datetime, timedelta, timezone
import math, random

app = Flask(__name__)

def make_series(symbol, minutes, count=100):
    # Dados sintéticos determinísticos: não representam preços reais da B3.
    seed = sum(ord(c) for c in symbol) + minutes
    rng = random.Random(seed)
    base = 128500.0 if symbol == "WIN" else 5750.0
    step = 18 if symbol == "WIN" else 2.5
    candles = []
    now = datetime.now(timezone.utc).replace(second=0, microsecond=0)
    now -= timedelta(minutes=now.minute % minutes)
    price = base
    for i in range(count):
        drift = math.sin(i / 8) * step * 0.15 + rng.uniform(-step, step)
        close = max(1, price + drift)
        op = price
        high = max(op, close) + rng.uniform(0, step * 0.6)
        low = min(op, close) - rng.uniform(0, step * 0.6)
        volume = rng.randint(500, 5000)
        stamp = int((now - timedelta(minutes=(count-i)*minutes)).timestamp())
        candles.append({"time": stamp, "open": round(op, 2), "high": round(high, 2),
                        "low": round(low, 2), "close": round(close, 2), "volume": volume})
        price = close
    return candles

def analyze(candles):
    closes = [c["close"] for c in candles]
    fast = sum(closes[-9:]) / 9
    slow = sum(closes[-21:]) / 21
    change = closes[-1] - closes[-6]
    if fast > slow and change > 0:
        signal = "COMPRA"
    elif fast < slow and change < 0:
        signal = "VENDA"
    else:
        signal = "AGUARDAR"
    last = closes[-1]
    return {"signal": signal, "last": round(last, 2),
            "ema9": round(fast, 2), "ema21": round(slow, 2),
            "stop": round(last - (18 if last > 10000 else 2.5) if signal == "COMPRA"
                          else last + (18 if last > 10000 else 2.5), 2),
            "target1": round(last + (36 if last > 10000 else 5) if signal == "COMPRA"
                             else last - (36 if last > 10000 else 5), 2),
            "target2": round(last + (54 if last > 10000 else 7.5) if signal == "COMPRA"
                             else last - (54 if last > 10000 else 7.5), 2)}

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/market")
def market():
    result = {}
    for symbol in ("WIN", "WDO"):
        result[symbol] = {}
        for minutes in (2, 5):
            candles = make_series(symbol, minutes)
            result[symbol][str(minutes)] = {"candles": candles, "analysis": analyze(candles)}
    return jsonify({"synthetic": True, "updated_at": datetime.now().isoformat(timespec="seconds"), "markets": result})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
