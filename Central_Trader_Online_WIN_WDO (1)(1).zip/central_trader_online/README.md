# Central Trader WIN/WDO — versão online demonstrativa

## Publicação gratuita no Render
1. Crie uma conta no GitHub e uma conta no Render.
2. No GitHub, crie um repositório público chamado `central-trader-win-wdo`.
3. Envie todos os arquivos e pastas deste projeto para a raiz do repositório.
4. No Render, escolha **New +** > **Blueprint** e conecte o repositório.
5. O Render reconhecerá `render.yaml`. Confirme a criação do serviço.
6. Aguarde o deploy e abra a URL `https://...onrender.com` fornecida pelo Render.

## Avisos
- Os preços, candles, indicadores e sinais são sintéticos e servem apenas para demonstrar a interface.
- Não há conexão com B3, Toro ou Profit, nem execução de ordens.
- A instância gratuita do Render pode entrar em repouso e demorar para acordar.
- Não coloque senhas, tokens ou dados da corretora no repositório.
